from config import app
import routes


if __name__== "__main__":
    app.run(debug=True)